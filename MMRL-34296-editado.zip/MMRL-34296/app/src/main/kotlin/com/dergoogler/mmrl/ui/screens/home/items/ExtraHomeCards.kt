package com.dergoogler.mmrl.ui.screens.home.items

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.system.Os
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.dergoogler.mmrl.R
import com.dergoogler.mmrl.ui.component.card.Card
import com.dergoogler.mmrl.ui.component.card.component.Relative
import com.dergoogler.mmrl.ui.component.listItem.dsl.ListScope
import com.dergoogler.mmrl.ui.component.listItem.dsl.component.Item
import com.dergoogler.mmrl.ui.component.listItem.dsl.component.item.Description
import com.dergoogler.mmrl.ui.component.listItem.dsl.component.item.Icon
import com.dergoogler.mmrl.ui.component.listItem.dsl.component.item.Title
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * Datos que cambian con el tiempo (RAM, batería, red, etc.).
 */
private data class LiveStats(
    val uptimeMs: Long,
    val ramUsed: Long,
    val ramTotal: Long,
    val storageUsed: Long,
    val storageTotal: Long,
    val batteryPercent: Int,
    val batteryTempC: Float,
    val charging: Boolean,
    @StringRes val networkRes: Int,
)

private fun readLiveStats(context: Context): LiveStats {
    // RAM
    var ramTotal = 0L
    var ramAvail = 0L
    runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        ramTotal = info.totalMem
        ramAvail = info.availMem
    }

    // Almacenamiento interno
    var storageTotal = 0L
    var storageFree = 0L
    runCatching {
        val stat = StatFs(Environment.getDataDirectory().path)
        storageTotal = stat.blockCountLong * stat.blockSizeLong
        storageFree = stat.availableBlocksLong * stat.blockSizeLong
    }

    // Batería
    var percent = -1
    var tempC = 0f
    var charging = false
    runCatching {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) percent = level * 100 / scale
        tempC = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        charging =
            status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
    }

    // Red
    var networkRes = R.string.home_x_net_none
    runCatching {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        networkRes =
            when {
                caps == null -> R.string.home_x_net_none
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> R.string.home_x_net_wifi
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> R.string.home_x_net_mobile
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> R.string.home_x_net_ethernet
                else -> R.string.home_x_net_other
            }
    }

    return LiveStats(
        uptimeMs = SystemClock.elapsedRealtime(),
        ramUsed = (ramTotal - ramAvail).coerceAtLeast(0L),
        ramTotal = ramTotal,
        storageUsed = (storageTotal - storageFree).coerceAtLeast(0L),
        storageTotal = storageTotal,
        batteryPercent = percent,
        batteryTempC = tempC,
        charging = charging,
        networkRes = networkRes,
    )
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = 0
    while (value >= 1024.0 && index < units.lastIndex) {
        value /= 1024.0
        index++
    }
    return String.format(Locale.US, "%.1f %s", value, units[index])
}

private fun formatUptime(ms: Long): String {
    val totalMinutes = ms / 60_000L
    val days = totalMinutes / (60L * 24L)
    val hours = (totalMinutes / 60L) % 24L
    val minutes = totalMinutes % 60L
    return buildString {
        if (days > 0) append("${days}d ")
        if (days > 0 || hours > 0) append("${hours}h ")
        append("${minutes}m")
    }
}

private fun fraction(
    used: Long,
    total: Long,
): Float = if (total <= 0L) 0f else (used.toFloat() / total.toFloat()).coerceIn(0f, 1f)

/**
 * Tarjetas extra para la pantalla Home:
 *  1. Información del dispositivo.
 *  2. Estado en vivo (tiempo encendido, RAM, almacenamiento, batería, red).
 *  3. Botón para copiar la información del dispositivo.
 */
@Composable
fun ListScope.ExtraHomeCards() {
    val scope = this
    val context = LocalContext.current

    // Se refresca cada 5 segundos.
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5_000L)
            tick++
        }
    }
    val stats = remember(tick) { readLiveStats(context) }

    val metrics = context.resources.displayMetrics
    val screenText = "${metrics.widthPixels} x ${metrics.heightPixels} (${metrics.densityDpi} dpi)"
    val cpuText =
        stringResource(R.string.home_x_cores, Runtime.getRuntime().availableProcessors()) +
            " · " + Build.SUPPORTED_ABIS.joinToString()
    val deviceText = "${Build.MANUFACTURER} ${Build.MODEL}"
    val androidText = "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"

    // ---------- 1. Información del dispositivo ----------
    Card(
        modifier = Modifier.padding(vertical = 16.dp),
    ) {
        Column(
            modifier = Modifier.relative(),
        ) {
            scope.Item {
                Icon(painter = painterResource(R.drawable.device_mobile_code))
                Title(R.string.home_x_device_title)
                Description(deviceText)
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.brand_android))
                Title(R.string.home_x_android_title)
                Description(androidText)
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.shield_bolt))
                Title(R.string.home_x_patch_title)
                Description(Build.VERSION.SECURITY_PATCH)
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.cpu_2))
                Title(R.string.home_x_cpu_title)
                Description(cpuText)
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.device_mobile_code))
                Title(R.string.home_x_screen_title)
                Description(screenText)
            }
        }
    }

    // ---------- 2. Estado en vivo ----------
    val batteryText =
        if (stats.batteryPercent >= 0) {
            val state =
                if (stats.charging) {
                    stringResource(R.string.home_x_charging)
                } else {
                    stringResource(R.string.home_x_not_charging)
                }
            "${stats.batteryPercent}% · ${String.format(Locale.US, "%.1f", stats.batteryTempC)} °C · $state"
        } else {
            "-"
        }

    Card(
        modifier = Modifier.padding(vertical = 16.dp),
    ) {
        Column(
            modifier = Modifier.relative(),
        ) {
            scope.Item {
                Icon(painter = painterResource(R.drawable.clock_24))
                Title(R.string.home_x_uptime_title)
                Description(formatUptime(stats.uptimeMs))
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.cpu_2))
                Title(R.string.home_x_ram_title)
                Description {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(text = formatBytes(stats.ramUsed))

                        LinearProgressIndicator(
                            progress = { fraction(stats.ramUsed, stats.ramTotal) },
                            modifier =
                                Modifier
                                    .height(10.dp)
                                    .weight(1f),
                            drawStopIndicator = {},
                        )

                        Text(text = formatBytes(stats.ramTotal))
                    }
                }
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.device_floppy))
                Title(R.string.home_x_storage_title)
                Description {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(text = formatBytes(stats.storageUsed))

                        LinearProgressIndicator(
                            progress = { fraction(stats.storageUsed, stats.storageTotal) },
                            modifier =
                                Modifier
                                    .height(10.dp)
                                    .weight(1f),
                            drawStopIndicator = {},
                        )

                        Text(text = formatBytes(stats.storageTotal))
                    }
                }
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.shield_bolt))
                Title(R.string.home_x_battery_title)
                Description(batteryText)
            }

            scope.Item {
                Icon(painter = painterResource(R.drawable.wifi))
                Title(R.string.home_x_network_title)
                Description(stringResource(stats.networkRes))
            }
        }
    }

    // ---------- 3. Copiar información del dispositivo ----------
    val copiedMessage = stringResource(R.string.home_x_copied)

    Card(
        modifier = Modifier.padding(vertical = 16.dp),
        onClick = {
            val kernel = runCatching { Os.uname().release }.getOrDefault("-")
            val report =
                buildString {
                    appendLine("Device: $deviceText")
                    appendLine("Android: $androidText")
                    appendLine("Security patch: ${Build.VERSION.SECURITY_PATCH}")
                    appendLine("Kernel: $kernel")
                    appendLine("CPU: $cpuText")
                    appendLine("Screen: $screenText")
                    appendLine("RAM: ${formatBytes(stats.ramTotal)}")
                    append("Storage: ${formatBytes(stats.storageTotal)}")
                }

            runCatching {
                val clipboard =
                    context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("device_info", report))
                Toast.makeText(context, copiedMessage, Toast.LENGTH_SHORT).show()
            }
        },
    ) {
        Relative {
            scope.Item {
                Icon(painter = painterResource(R.drawable.share))
                Title(R.string.home_x_copy_title)
                Description(R.string.home_x_copy_desc)
            }
        }
    }
}
